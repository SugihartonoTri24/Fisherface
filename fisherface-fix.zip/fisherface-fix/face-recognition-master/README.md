face-recognition
================

Face recognition with OpenCV


Demo Application of Face Recognition with Open CV

It uses JavaCV to access the face recognition algorithims in OpenCV.

The LBPH algorithm is chosen in this implementation for best resuls, but you can easily adapt one of the other algorithms in OpenCV

This version is for eclipse. If you use Android Studio,download the foldera and import project from Andoid Studio.
