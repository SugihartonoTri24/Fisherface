package org.opencv.javacv.facerecognition;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TambahdataActivity extends Activity {
	Button btnRegister;
	Button btnLinkToLogin;
	EditText inputFullName;
	EditText inputEmail;
	EditText inputPassword;
	EditText inputPassword2;
	EditText ktp, namalaengkap, alamat, notelp;
	TextView registerErrorMsg;

	ProgressDialog progressDialog;

	// JSON Response node names
	private static String KEY_SUCCESS = "success";
	private static String KEY_ERROR = "error";
	private static String KEY_ERROR_MSG = "error_msg";
	private static String KEY_UID = "uid";
	private static String KEY_NAME = "name";
	private static String KEY_EMAIL = "email";
	private static String KEY_CREATED_AT = "created_at";

	String nim, nama, fk;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.absen);

		Intent in = getIntent();
		nim = in.getStringExtra("nima");
		nama = in.getStringExtra("nama");
		fk = in.getStringExtra("fakultas");

		progressDialog = ProgressDialog.show(TambahdataActivity.this, "",
				"Proses.....", false);
		Thread thread = new Thread(new Runnable() {
			public void run() {
				doinput();
				runOnUiThread(new Runnable() {
					public void run() {
						if (progressDialog.isShowing()) {
							progressDialog.dismiss();
							Toast.makeText(TambahdataActivity.this, "Berhasil!",
									Toast.LENGTH_LONG).show();
							TambahdataActivity.this.finish();
						}
					}
				});
			}
		});
		thread.start();

	}

	private void doinput() {

		// TODO Auto-generated method stub

		String input_data = "http://bepeto.com/apiabsen/tambahuser.php"; // URL
		HttpClient httpClient = new DefaultHttpClient();
		HttpPost httpPost = new HttpPost(input_data);

		ArrayList<NameValuePair> param = new ArrayList<NameValuePair>();
		param.add(new BasicNameValuePair("nim", nim.toString()));
		param.add(new BasicNameValuePair("nama", nama.toString()));
		param.add(new BasicNameValuePair("fakul", fk.toString()));

		try {
			httpPost.setEntity(new UrlEncodedFormEntity(param));
			HttpResponse httpRespose = httpClient.execute(httpPost);
			HttpEntity httpEntity = httpRespose.getEntity();
			InputStream in = httpEntity.getContent();
			BufferedReader read = new BufferedReader(new InputStreamReader(in));

			String isi = "";
			String baris = "";

			while ((baris = read.readLine()) != null) {
				isi += baris;
			}

			// Jika isi tidak sama dengan "null " maka akan tampil Toast
			// "Berhasil" sebaliknya akan tampil "Gagal"
			if (!isi.equals("null")) {
			} else {
			}

		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
