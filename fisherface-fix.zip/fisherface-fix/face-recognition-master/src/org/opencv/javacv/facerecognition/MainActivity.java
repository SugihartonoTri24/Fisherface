package org.opencv.javacv.facerecognition;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;




import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	public int currentimageindex = 0;
	ImageView slidingimage;
	RelativeLayout konsultasi, penuu, pengaturan, bantuan, btnuu;
	TextView t;
	SessionManager session;
	  HashMap<String, String> user;


	    // Progress Dialog
	    private ProgressDialog pDialog;
	 
	    // Progress dialog type (0 - for Horizontal progress bar)
	    public static final int progress_bar_type = 0; 
		 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		session = new SessionManager(getApplicationContext());
		 user = session.getUserDetails();
		 
		
		
		konsultasi = (RelativeLayout)findViewById(R.id.btnkonsultasi);
		bantuan = (RelativeLayout)findViewById(R.id.btnbantuan);
		pengaturan = (RelativeLayout)findViewById(R.id.btnpengaturan);
		penuu = (RelativeLayout)findViewById(R.id.login);
		btnuu = (RelativeLayout)findViewById(R.id.btnuu);
		
		konsultasi.setOnClickListener(this);
		bantuan.setOnClickListener(this);
		pengaturan.setOnClickListener(this);
		penuu.setOnClickListener(this);
		btnuu.setOnClickListener(this);
		
		 if(session.isLoggedIn()){
				t = (TextView)findViewById(R.id.s);
				 btnuu.setVisibility(View.VISIBLE);
				t.setText("Logout");
		 }else{
			 t = (TextView)findViewById(R.id.s);
			 btnuu.setVisibility(View.GONE);
				t.setText("Login Admin");
		 }
	}



	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnkonsultasi:
			Intent intent = new Intent(this, FdActivity.class);
			startActivity(intent);
			break;
	
			
		case R.id.btnbantuan:
			Intent intent4 = new Intent(this, about.class);
			startActivity(intent4);
			break;
			
		case R.id.btnuu:
			AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
			 
	        // Setting Dialog Title
	        alertDialog.setTitle("Choose");
	 
	        // Setting Dialog Message
	        alertDialog.setMessage("Pilih jenis laporan");
	 
	        // Setting Icon to Dialog
	 
	        // Setting Positive "Yes" Button
	        alertDialog.setPositiveButton("PDF", new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog,int which) {
	            	new DownloadFileFromURL2().execute("http://bepeto.com/apiabsen/pdf.php?dari=16/12/2015&sampai=16/01/2016");
	            // Write your code here to invoke YES event
	            }
	        });
	 
	        // Setting Negative "NO" Button
	        alertDialog.setNegativeButton("XLS", new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int which) {
	            // Write your code here to invoke NO event
	            	new DownloadFileFromURL().execute("http://bepeto.com/apiabsen/report.php");
	            }
	        });
	 
	        // Showing Alert Message
	        alertDialog.show();
			break;
			
		case R.id.login:
//		
			 if(session.isLoggedIn()){
					session.logoutUser();
			 }else{
				 Intent intent3 = new Intent(this, login.class);
					startActivity(intent3);
			 }
			
			break;
			
		case R.id.btnpengaturan:
			Intent intent5 = new Intent(this, tentang.class);
			startActivity(intent5);
			break;
		}
	}
	
	/**
	 * Showing Dialog
	 * */
	@Override
	protected Dialog onCreateDialog(int id) {
	    switch (id) {
	    case progress_bar_type:
	        pDialog = new ProgressDialog(this);
	        pDialog.setMessage("Downloading file. Please wait...");
	        pDialog.setIndeterminate(false);
	        pDialog.setMax(100);
	        pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
	        pDialog.setCancelable(true);
	        pDialog.show();
	        return pDialog;
	    default:
	        return null;
	    }
	}
	
	/**
	 * Background Async Task to download file
	 * */
	class DownloadFileFromURL2 extends AsyncTask<String, String, String> {
	 
	    /**
	     * Before starting background thread
	     * Show Progress Bar Dialog
	     * */
	    @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	        showDialog(progress_bar_type);
	    }
	 
	    /**
	     * Downloading file in background thread
	     * */
	    @Override
	    protected String doInBackground(String... f_url) {
	        int count;
	        try {
	            URL url = new URL(f_url[0]);
	            URLConnection conection = url.openConnection();
	            conection.connect();
	            // getting file length
	            int lenghtOfFile = conection.getContentLength();
	 
	            // input stream to read file - with 8k buffer
	            InputStream input = new BufferedInputStream(url.openStream(), 8192);
	 
	            // Output stream to write file
	            OutputStream output = new FileOutputStream("/sdcard/reportabsen.pdf");
	 
	            byte data[] = new byte[1024];
	 
	            long total = 0;
	 
	            while ((count = input.read(data)) != -1) {
	                total += count;
	                // publishing the progress....
	                // After this onProgressUpdate will be called
	                publishProgress(""+(int)((total*100)/lenghtOfFile));
	 
	                // writing data to file
	                output.write(data, 0, count);
	            }
	 
	            // flushing output
	            output.flush();
	 
	            // closing streams
	            output.close();
	            input.close();
	 
	        } catch (Exception e) {
	            Log.e("Error: ", e.getMessage());
	        }
	 
	        return null;
	    }
	 
	    /**
	     * Updating progress bar
	     * */
	    protected void onProgressUpdate(String... progress) {
	        // setting progress percentage
	        pDialog.setProgress(Integer.parseInt(progress[0]));
	   }
	 
	    /**
	     * After completing background task
	     * Dismiss the progress dialog
	     * **/
	    @Override
	    protected void onPostExecute(String file_url) {
	        // dismiss the dialog after the file was downloaded
	        dismissDialog(progress_bar_type);
	 Toast.makeText(MainActivity.this, "Download berhasil", Toast.LENGTH_SHORT).show();
	    }
	 
	}
	
	/**
	 * Background Async Task to download file
	 * */
	class DownloadFileFromURL extends AsyncTask<String, String, String> {
	 
	    /**
	     * Before starting background thread
	     * Show Progress Bar Dialog
	     * */
	    @Override
	    protected void onPreExecute() {
	        super.onPreExecute();
	        showDialog(progress_bar_type);
	    }
	 
	    /**
	     * Downloading file in background thread
	     * */
	    @Override
	    protected String doInBackground(String... f_url) {
	        int count;
	        try {
	            URL url = new URL(f_url[0]);
	            URLConnection conection = url.openConnection();
	            conection.connect();
	            // getting file length
	            int lenghtOfFile = conection.getContentLength();
	 
	            // input stream to read file - with 8k buffer
	            InputStream input = new BufferedInputStream(url.openStream(), 8192);
	 
	            // Output stream to write file
	            OutputStream output = new FileOutputStream("/sdcard/reportabsen.xls");
	 
	            byte data[] = new byte[1024];
	 
	            long total = 0;
	 
	            while ((count = input.read(data)) != -1) {
	                total += count;
	                // publishing the progress....
	                // After this onProgressUpdate will be called
	                publishProgress(""+(int)((total*100)/lenghtOfFile));
	 
	                // writing data to file
	                output.write(data, 0, count);
	            }
	 
	            // flushing output
	            output.flush();
	 
	            // closing streams
	            output.close();
	            input.close();
	 
	        } catch (Exception e) {
	            Log.e("Error: ", e.getMessage());
	        }
	 
	        return null;
	    }
	 
	    /**
	     * Updating progress bar
	     * */
	    protected void onProgressUpdate(String... progress) {
	        // setting progress percentage
	        pDialog.setProgress(Integer.parseInt(progress[0]));
	   }
	 
	    /**
	     * After completing background task
	     * Dismiss the progress dialog
	     * **/
	    @Override
	    protected void onPostExecute(String file_url) {
	        // dismiss the dialog after the file was downloaded
	        dismissDialog(progress_bar_type);
	 Toast.makeText(MainActivity.this, "Download berhasil", Toast.LENGTH_SHORT).show();
	    }
	 
	}
	
	 @Override
		public boolean onKeyDown(int keyCode, KeyEvent event)  {
		    if (keyCode == KeyEvent.KEYCODE_BACK ) {
		        // do something on back.
		    	Intent intent = new Intent(Intent.ACTION_MAIN);
		          intent.addCategory(Intent.CATEGORY_HOME);
		          intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//***Change Here***
		          startActivity(intent);
		          finish();
		          System.exit(0);
		        return true;
		    }

		    return super.onKeyDown(keyCode, event);
		}

}
