package org.opencv.javacv.facerecognition;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	Button btnRegister;
	Button btnLinkToLogin;
	EditText inputFullName;
	EditText inputEmail;
	EditText inputPassword;
	EditText inputPassword2;
	EditText ktp, namalaengkap, alamat, notelp;
	TextView registerErrorMsg;

	ProgressDialog progressDialog;

	// JSON Response node names
	private static String KEY_SUCCESS = "success";
	private static String KEY_ERROR = "error";
	private static String KEY_ERROR_MSG = "error_msg";
	private static String KEY_UID = "uid";
	private static String KEY_NAME = "name";
	private static String KEY_EMAIL = "email";
	private static String KEY_CREATED_AT = "created_at";
	public static final String TAG_CONTACTS = "info";
	public static final String TAG_IDUSER = "iduser";
	
	String id,idd;

	String nim, nama, fk;
	private ProgressDialog pDialog,pDialog2;
	JSONArray contacts = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.absen);

		Intent in = getIntent();
		nim = in.getStringExtra("nim");

		 new LoadInbox().execute();

	}
	
	class LoadInbox extends AsyncTask<String, String, String> {
		
				/**
				 * Before starting background thread Show Progress Dialog
				 * */
				@Override
				protected void onPreExecute() {
					super.onPreExecute();
					pDialog = new ProgressDialog(
							RegisterActivity.this);
					pDialog.setMessage("Please wait..");
					pDialog.setIndeterminate(true);
					pDialog.setCancelable(false);
					pDialog.show();
				
				}
		
				/**
				 * getting Inbox JSON
				 * */
				protected String doInBackground(String... args) {
					// Creating JSON Parser instance
					JSONParser jParser = new JSONParser();
			
					// getting JSON string from URL
					JSONObject json = jParser.getJSONFromUrl("http://bepeto.com/apiabsen/checklogin.php?user="+nim);
			
					try {
						// Getting Array of Contacts
						contacts = json.getJSONArray(TAG_CONTACTS);
						
						// looping through All Contacts
						for(int i = 0; i < contacts.length(); i++){
							JSONObject c = contacts.getJSONObject(i);
							
//							// Storing each json item in variable
							id = c.getString(TAG_IDUSER);
							
//							String nama = c.getString(TAG_NAMEDATACENTER);
//							String location = c.getString(TAG_LOCATIONDATACENTER);
//							String ip = c.getString(TAG_IPDATACENTER);
							
							// creating new HashMap
//							HashMap<String, String> map = new HashMap<String, String>();
							
							// adding each child node to HashMap key => value
							// adding each child node to HashMap key => value
//							map.put(TAG_IDDATACENTER, id);
//							map.put(TAG_NAMEDATACENTER, nama);
//							map.put(TAG_LOCATIONDATACENTER, location);
//							map.put(TAG_IPDATACENTER, ip);
			
							// adding HashList to ArrayList
							
						
//							contactList.add(map);
						}
					} catch (JSONException e) {
						e.printStackTrace();
					}
					
					
					return null;
				}
				protected void onPostExecute(String file_url) {
				pDialog.dismiss();
				
				if(id == null){
					progressDialog = ProgressDialog.show(RegisterActivity.this, "",
							"Proses.....", false);
					Thread thread = new Thread(new Runnable() {
						public void run() {
							doinput();
							runOnUiThread(new Runnable() {
								public void run() {
									if (progressDialog.isShowing()) {
										progressDialog.dismiss();
										new LoadInbox2().execute();
									
									
									}
								}
							});
						}
					});
					thread.start();
				
				}else{
					Toast.makeText(RegisterActivity.this, "Anda sudah absen", Toast.LENGTH_SHORT).show();
					Intent intent5 = new Intent(RegisterActivity.this, MainActivity.class);
					startActivity(intent5);
				}
			}}
	
	
	class LoadInbox2 extends AsyncTask<String, String, String> {
		
		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog2 = new ProgressDialog(
					RegisterActivity.this);
			pDialog2.setMessage("Please wait..");
			pDialog2.setIndeterminate(true);
			pDialog2.setCancelable(false);
			pDialog2.show();
		
		}

		/**
		 * getting Inbox JSON
		 * */
		protected String doInBackground(String... args) {
			// Creating JSON Parser instance
			JSONParser jParser = new JSONParser();
	
			// getting JSON string from URL
			JSONObject json = jParser.getJSONFromUrl("http://bepeto.com/apiabsen/check.php?user="+nim);
	
			try {
				// Getting Array of Contacts
				contacts = json.getJSONArray(TAG_CONTACTS);
				
				// looping through All Contacts
				for(int i = 0; i < contacts.length(); i++){
					JSONObject c = contacts.getJSONObject(i);
					
//					// Storing each json item in variable
					idd = c.getString(TAG_IDUSER);
					
//					String nama = c.getString(TAG_NAMEDATACENTER);
//					String location = c.getString(TAG_LOCATIONDATACENTER);
//					String ip = c.getString(TAG_IPDATACENTER);
					
					// creating new HashMap
//					HashMap<String, String> map = new HashMap<String, String>();
					
					// adding each child node to HashMap key => value
					// adding each child node to HashMap key => value
//					map.put(TAG_IDDATACENTER, id);
//					map.put(TAG_NAMEDATACENTER, nama);
//					map.put(TAG_LOCATIONDATACENTER, location);
//					map.put(TAG_IPDATACENTER, ip);
	
					// adding HashList to ArrayList
					
				
//					contactList.add(map);
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			
			
			return null;
		}
		protected void onPostExecute(String file_url) {
		pDialog2.dismiss();
		Toast.makeText(RegisterActivity.this, "Berhasil! nim: "+nim+" Nama: "+idd,
				Toast.LENGTH_LONG).show();
		Intent intent5 = new Intent(RegisterActivity.this, MainActivity.class);
		startActivity(intent5);
	}}

	private void doinput() {

		// TODO Auto-generated method stub

		String input_data = "http://bepeto.com/apiabsen/registerguru.php"; // URL
		HttpClient httpClient = new DefaultHttpClient();
		HttpPost httpPost = new HttpPost(input_data);

		ArrayList<NameValuePair> param = new ArrayList<NameValuePair>();
		param.add(new BasicNameValuePair("nim", nim));

		try {
			httpPost.setEntity(new UrlEncodedFormEntity(param));
			HttpResponse httpRespose = httpClient.execute(httpPost);
			HttpEntity httpEntity = httpRespose.getEntity();
			InputStream in = httpEntity.getContent();
			BufferedReader read = new BufferedReader(new InputStreamReader(in));

			String isi = "";
			String baris = "";

			while ((baris = read.readLine()) != null) {
				isi += baris;
			}

			// Jika isi tidak sama dengan "null " maka akan tampil Toast
			// "Berhasil" sebaliknya akan tampil "Gagal"
			if (!isi.equals("null")) {
			} else {
			}

		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
