package org.opencv.javacv.facerecognition;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;







import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class login extends Activity{
	
	EditText user, pass;
	Button btnlogin;
	SessionManager session;
	
	private ProgressDialog pDialog;
	ArrayList<HashMap<String, String>> contactList;
	// url to make request
	static String url;
	JSONArray contacts = null;
	
	//pref
	// JSON Response node names
	String id, nama, level, foto, idserver ;

	public static final String TAG_CONTACTS = "info";
	public static final String TAG_IDUSER = "iduser";
	
	static final String JUDUL11="a",JUDUL12="b",JUDUL13="c",JUDUL14="d",JUDUL15="e";
	
	// flag for Internet connection status
	Boolean isInternetPresent = false;
	
	TextView btnregis;
	
	// Connection detector class
	ConnectionDetector cd;
	Button regisSiswa, regisGuru;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
//		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//        StrictMode.setThreadPolicy(policy);
        session = new SessionManager(login.this.getApplicationContext());
//        
//        
//		 cd = new ConnectionDetector(getApplicationContext());
//
//			isInternetPresent = cd.isConnectingToInternet();
//
//			// check for Internet status
//			if (isInternetPresent) {
//				// Internet Connection is Present
//				
//			} else {
//				Toast.makeText(login.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
//			}
//        
//        if(session.isLoggedIn()){
//        	Intent in = new Intent(login.this, MainActivity.class);
//        	startActivity(in);
//        	finish();
//        }
		
		user = (EditText) findViewById(R.id.loginEmail);
		pass = (EditText) findViewById(R.id.loginPassword);
//		btnregis = (TextView) findViewById(R.id.btnLinkToRegisterScreen);
		
//		btnregis.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				Intent in = new Intent(login.this, RegisterActivity.class);
//				startActivity(in);
//			}
//		});
		
		btnlogin = (Button) findViewById(R.id.btnlogin);
		
		btnlogin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(user.getText().toString().equalsIgnoreCase("")){
					Toast.makeText(login.this, "User field can't be blank", Toast.LENGTH_SHORT).show();
				}
				if(pass.getText().toString().equalsIgnoreCase("")){
					Toast.makeText(login.this, "password field can't be blank", Toast.LENGTH_SHORT).show();
				}
				
				if(!user.getText().toString().equalsIgnoreCase("") && !pass.getText().toString().equalsIgnoreCase("")){
				String suser= user.getText().toString();
				String spass= pass.getText().toString();
				
				if(suser.equals("admin") && spass.equals("admin")){
					Toast.makeText(login.this, "Login Success", Toast.LENGTH_SHORT).show();
					session.createLoginSession("admin", "pass");
					Intent in = new Intent(login.this, MainActivity.class);
					startActivity(in);
				}else{
					Toast.makeText(login.this, "password salah", Toast.LENGTH_SHORT).show();

				}
				
				
				}
			}
		});
		
	}
	
	
//	class LoadInbox extends AsyncTask<String, String, String> {
//
//		/**
//		 * Before starting background thread Show Progress Dialog
//		 * */
//		@Override
//		protected void onPreExecute() {
//			super.onPreExecute();
//			pDialog = new ProgressDialog(
//					login.this);
//			pDialog.setMessage("Please wait..");
//			pDialog.setIndeterminate(true);
//			pDialog.setCancelable(false);
//			pDialog.show();
//		
//		}
//
//		/**
//		 * getting Inbox JSON
//		 * */
//		protected String doInBackground(String... args) {
//			// Creating JSON Parser instance
//			JSONParser jParser = new JSONParser();
//	
//			// getting JSON string from URL
//			JSONObject json = jParser.getJSONFromUrl(url);
//	
//			try {
//				// Getting Array of Contacts
//				contacts = json.getJSONArray(TAG_CONTACTS);
//				
//				// looping through All Contacts
//				for(int i = 0; i < contacts.length(); i++){
//					JSONObject c = contacts.getJSONObject(i);
//					
////					// Storing each json item in variable
//					id = c.getString(TAG_IDUSER);
//					
////					String nama = c.getString(TAG_NAMEDATACENTER);
////					String location = c.getString(TAG_LOCATIONDATACENTER);
////					String ip = c.getString(TAG_IPDATACENTER);
//					
//					// creating new HashMap
////					HashMap<String, String> map = new HashMap<String, String>();
//					
//					// adding each child node to HashMap key => value
//					// adding each child node to HashMap key => value
////					map.put(TAG_IDDATACENTER, id);
////					map.put(TAG_NAMEDATACENTER, nama);
////					map.put(TAG_LOCATIONDATACENTER, location);
////					map.put(TAG_IPDATACENTER, ip);
//	
//					// adding HashList to ArrayList
//					
//				
////					contactList.add(map);
//				}
//			} catch (JSONException e) {
//				e.printStackTrace();
//			}
//			
//			
//			return null;
//		}
//		protected void onPostExecute(String file_url) {
//		pDialog.dismiss();
//		
//		if(id == null){
//		
//		Toast.makeText(login.this, "Invalid username or password / not verified by admin", Toast.LENGTH_SHORT).show();
//		}else{
//			session.createLoginSession(id, "pass");
//			Intent in = new Intent(login.this, MainActivity.class);
//			startActivity(in);
//		}
//	}}
//	
	 @Override
		public boolean onKeyDown(int keyCode, KeyEvent event)  {
		    if (keyCode == KeyEvent.KEYCODE_BACK ) {
		        // do something on back.
		    	Intent intent = new Intent(login.this, MainActivity.class);
		          startActivity(intent);
		        return true;
		    }
		    return super.onKeyDown(keyCode, event);
		}
	
	
}
