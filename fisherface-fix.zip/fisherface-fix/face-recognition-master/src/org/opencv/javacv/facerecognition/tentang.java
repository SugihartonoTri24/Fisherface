package org.opencv.javacv.facerecognition;

import android.app.Activity;
import android.os.Bundle;

public class tentang extends Activity{

	
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.tentang);
	 }
}
