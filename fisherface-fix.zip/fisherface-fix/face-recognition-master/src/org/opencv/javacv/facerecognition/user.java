package org.opencv.javacv.facerecognition;

public class user {

}
