/** Automatically generated file. DO NOT MODIFY */
package org.opencv.javacv.facerecognition;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}